def say_hello():
    return "Hello Jenkins! Everything is working."

if __name__ == "__main__":
    print(say_hello())